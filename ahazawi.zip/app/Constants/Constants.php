<?php

namespace App\Constants;

class Constants
{
   public const DEFAULT_STATE = "PENDING";
   public const DEFAULT_MAX_ALLOWED_COURSES = 1;
   public const DEFULT_MAX_ALLOWED_LEARNERS = 1;
   Public const DEFAULT_ENROLLED_COURSES = 0;
   Public const DEFAULT_ADDED_LEARNERS = 1;
}
